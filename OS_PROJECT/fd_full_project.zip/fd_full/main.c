/*
 * main.c  -  COMPLETE PROJECT
 * Linux File Descriptor and File I/O Management System
 * with Internal Execution Visualizer
 *
 * What it does
 *   You run file operations from a menu. In LEARNING MODE the program also
 *   prints an Internal Execution Trace that shows the journey:
 *     user command -> user-space code -> system call -> kernel service ->
 *     VFS / filesystem -> open file description -> inode -> result
 *
 * How to read the trace (IMPORTANT)
 *   [REAL]    = a value measured by THIS program while it runs
 *               (PID, FD number, offset, bytes, errno, pipe FDs, counters...)
 *   [CONCEPT] = an explanation of what Linux does inside the kernel.
 *               A normal program cannot read private kernel memory or raw
 *               disk blocks, so those lines are explanations, not measurements.
 *
 * Course outcomes
 *   CO-1  system calls, user space -> kernel space      (every operation)
 *   CO-2  fork(), waitpid(), exit status                (option 10)
 *   CO-3  two pipes, sigaction() SIGINT and SIGCHLD     (option 10, Ctrl+C)
 *   CO-4  malloc/free buffers, shared mmap() statistics (options 3,4,10,11)
 *   CO-5  open/read/write/lseek/close/dup/dup2/fcntl/stat (options 2-9,14)
 *   CO-6  logger thread + mutex + semaphore -> audit.log (option 12)
 *
 * Compile:  gcc -Wall -Wextra -pthread -o fd_manager main.c
 * Run:      ./fd_manager
 */

#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <semaphore.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define PATH_LEN   256
#define LINE_LEN   512
#define MAX_READ   1000
#define MAX_FILES  16
#define COPY_BUF   4096
#define LOG_QUEUE  64
#define LOG_TEXT   200
#define THR_LINES  24
#define THR_LEN    200

/* ======================================================================
 * CO-4: shared statistics. This struct lives in memory created with
 * mmap(MAP_SHARED | MAP_ANONYMOUS), so the parent AND the child worker
 * process see the SAME counters.
 * ====================================================================== */
enum { WORKER_IDLE = 0, WORKER_RUNNING, WORKER_COMPLETED, WORKER_FAILED };

typedef struct {
    long files_opened;
    long reads;
    long writes;
    long bytes_read;
    long bytes_written;
    long errors;
    long copies_done;
    int  worker_status;
} IOStats;

static IOStats *g_stats = NULL;

/* Ordinary variable. After fork() the child gets its OWN copy, so a change
 * made by the child is NOT visible to the parent (used in option 10). */
static int g_private_counter = 0;

/* add to a shared counter safely */
static void stat_add(long *field, long amount)
{
    __sync_fetch_and_add(field, amount);
}

/* ======================================================================
 * Global program state
 * ====================================================================== */
static int g_learning = 1;                 /* 1 = Learning Mode, 0 = Basic Mode */

/* The descriptors that the user opened (or duplicated) through the menu.
 * 'group' says which descriptors share ONE open file description (dup). */
typedef struct {
    int  fd;                               /* -1 = unused slot */
    int  group;
    char name[PATH_LEN];
} Slot;

static Slot g_slots[MAX_FILES];
static int  g_next_group = 1;

/* pipe ends used by option 10 (only for labelling the descriptor table) */
static int g_pipe_cmd[2] = { -1, -1 };     /* parent -> child */
static int g_pipe_res[2] = { -1, -1 };     /* child  -> parent */

/* ======================================================================
 * Trace helpers: print ONLY in Learning Mode
 * ====================================================================== */
static void trace_begin(const char *title)
{
    if (!g_learning) return;
    printf("\n========== INTERNAL EXECUTION TRACE: %s ==========\n", title);
    printf("(  [REAL] = measured by this program,  [CONCEPT] = Linux explanation  )\n");
    fflush(stdout);
}

static void trace_end(void)
{
    if (!g_learning) return;
    printf("=====================================================\n");
    fflush(stdout);
}

static void trace_heading(const char *text)
{
    if (!g_learning) return;
    printf("\n[%s]\n", text);
    fflush(stdout);
}

static void trace_line(const char *fmt, ...)
{
    va_list ap;
    if (!g_learning) return;
    va_start(ap, fmt);
    vprintf(fmt, ap);
    va_end(ap);
    printf("\n");
    fflush(stdout);
}

static void trace_concept(const char *fmt, ...)
{
    va_list ap;
    if (!g_learning) return;
    printf("  [CONCEPT] ");
    va_start(ap, fmt);
    vprintf(fmt, ap);
    va_end(ap);
    printf("\n");
    fflush(stdout);
}

static void trace_real(const char *fmt, ...)
{
    va_list ap;
    if (!g_learning) return;
    printf("  [REAL]    ");
    va_start(ap, fmt);
    vprintf(fmt, ap);
    va_end(ap);
    printf("\n");
    fflush(stdout);
}

/* Print a system-call failure and count it in the shared statistics. */
static void report_error(const char *call, int err)
{
    printf("ERROR: %s failed: %s (errno = %d)\n", call, strerror(err), err);
    fflush(stdout);
    if (g_stats) stat_add(&g_stats->errors, 1);
}

/* ======================================================================
 * CO-3: signal handling with sigaction()
 * A handler must be tiny: it only sets a flag; the main code reacts later.
 * ====================================================================== */
static volatile sig_atomic_t g_sigint = 0;          /* Ctrl+C pressed       */
static volatile sig_atomic_t g_sigchld_count = 0;   /* children that ended  */

static void on_sigint(int sig)  { (void)sig; g_sigint = 1; }
static void on_sigchld(int sig) { (void)sig; g_sigchld_count++; }

static void install_signal_handlers(void)
{
    struct sigaction sa;

    memset(&sa, 0, sizeof sa);
    sigemptyset(&sa.sa_mask);

    sa.sa_handler = on_sigint;          /* no SA_RESTART: Ctrl+C must interrupt fgets() */
    sa.sa_flags = 0;
    if (sigaction(SIGINT, &sa, NULL) == -1) perror("sigaction(SIGINT)");

    sa.sa_handler = on_sigchld;         /* tell us when a child process ends */
    sa.sa_flags = SA_RESTART | SA_NOCLDSTOP;
    if (sigaction(SIGCHLD, &sa, NULL) == -1) perror("sigaction(SIGCHLD)");

    sa.sa_handler = SIG_IGN;            /* writing to a closed pipe returns EPIPE instead of killing us */
    sa.sa_flags = 0;
    if (sigaction(SIGPIPE, &sa, NULL) == -1) perror("sigaction(SIGPIPE)");
}

/* ======================================================================
 * Input helpers
 * ====================================================================== */

/* Read one line. Returns 0 = ok, -1 = end of input, -2 = Ctrl+C pressed. */
static int read_line(const char *prompt, char *buf, size_t size)
{
    if (g_sigint) return -2;
    printf("%s", prompt);
    fflush(stdout);
    if (fgets(buf, (int)size, stdin) == NULL) {
        if (g_sigint) {                 /* fgets() was interrupted by SIGINT */
            clearerr(stdin);
            printf("\n");
            return -2;
        }
        return -1;
    }
    buf[strcspn(buf, "\n")] = '\0';
    return 0;
}

static int read_number(const char *prompt, long *value)
{
    char line[64], *end;
    int rc;

    for (;;) {
        rc = read_line(prompt, line, sizeof line);
        if (rc != 0) return rc;
        *value = strtol(line, &end, 10);
        if (end != line && *end == '\0') return 0;
        printf("Please type a whole number.\n");
    }
}

/* read() that restarts itself if a signal interrupts it */
static ssize_t read_retry(int fd, void *buf, size_t count)
{
    ssize_t n;
    do { n = read(fd, buf, count); } while (n == -1 && errno == EINTR);
    return n;
}

/* write() that keeps going until everything is written. Returns 0 or -1. */
static int write_all(int fd, const char *buf, size_t count)
{
    while (count > 0) {
        ssize_t n = write(fd, buf, count);
        if (n == -1) {
            if (errno == EINTR) continue;
            return -1;
        }
        buf += n;
        count -= (size_t)n;
    }
    return 0;
}

/* ======================================================================
 * CO-6: logger thread
 *
 *   Menu code  --log_event()-->  queue (protected by a MUTEX)
 *                                  |  sem_post()  (the SEMAPHORE wakes the logger)
 *                                  v
 *   Logger thread: sem_wait() -> lock mutex -> write() to audit.log -> unlock
 *
 * The mutex stops two threads from changing the queue / writing the log at
 * the same moment (a race condition).
 * ====================================================================== */
typedef struct {
    time_t when;
    char   text[LOG_TEXT];
} LogEvent;

static LogEvent        g_queue[LOG_QUEUE];
static int             g_q_head, g_q_tail, g_q_count;
static pthread_mutex_t g_log_mutex = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  g_idle_cond = PTHREAD_COND_INITIALIZER;
static sem_t           g_log_sem;
static pthread_t       g_logger;
static int             g_logger_started = 0;
static int             g_log_quit = 0;
static int             g_audit_fd = -1;
static long            g_posted = 0, g_processed = 0, g_dropped = 0, g_last_seq = 0;
static char            g_last_text[LOG_TEXT] = "";

/* what the logger thread did, recorded for the Learning Mode trace */
static char g_thr_trace[THR_LINES][THR_LEN];
static int  g_thr_n = 0;

/* caller must hold g_log_mutex */
static void thr_note(const char *fmt, ...)
{
    va_list ap;
    if (g_thr_n >= THR_LINES) return;
    va_start(ap, fmt);
    vsnprintf(g_thr_trace[g_thr_n], THR_LEN, fmt, ap);
    va_end(ap);
    g_thr_n++;
}

static void *logger_main(void *arg)
{
    (void)arg;

    for (;;) {
        /* wait until somebody posts the semaphore */
        while (sem_wait(&g_log_sem) == -1 && errno == EINTR) { }

        int was_busy = (pthread_mutex_trylock(&g_log_mutex) == EBUSY);
        if (was_busy) pthread_mutex_lock(&g_log_mutex);

        if (g_q_count == 0) {                  /* woken only to quit */
            int quit = g_log_quit;
            pthread_mutex_unlock(&g_log_mutex);
            if (quit) break;
            continue;
        }

        LogEvent ev = g_queue[g_q_head];
        g_q_head = (g_q_head + 1) % LOG_QUEUE;
        g_q_count--;

        thr_note("[Logger Thread] woke up: sem_wait() returned (thread id %lu)", (unsigned long)pthread_self());
        thr_note("[Logger Thread] pthread_mutex_lock(): mutex was %s, now acquired",
                 was_busy ? "BUSY - had to wait" : "free");

        char ts[32], line[LOG_TEXT + 64];
        struct tm tmv;
        localtime_r(&ev.when, &tmv);
        strftime(ts, sizeof ts, "%Y-%m-%d %H:%M:%S", &tmv);
        int len = snprintf(line, sizeof line, "[%s] %s\n", ts, ev.text);

        ssize_t w = write(g_audit_fd, line, (size_t)len);
        thr_note("[Logger Thread] write(audit.log) wrote %zd of %d bytes", w, len);
        if (w != len && g_stats) stat_add(&g_stats->errors, 1);

        thr_note("[Logger Thread] pthread_mutex_unlock(): mutex released, back to sem_wait()");
        g_processed++;
        if (g_processed == g_posted) pthread_cond_broadcast(&g_idle_cond);
        pthread_mutex_unlock(&g_log_mutex);
    }
    return NULL;
}

/* Called by the menu code: queue one event and wake the logger thread. */
static void log_event(const char *fmt, ...)
{
    LogEvent ev;
    va_list ap;

    if (!g_logger_started) return;

    ev.when = time(NULL);
    va_start(ap, fmt);
    vsnprintf(ev.text, sizeof ev.text, fmt, ap);
    va_end(ap);

    pthread_mutex_lock(&g_log_mutex);
    if (g_q_count == LOG_QUEUE) {              /* queue full: drop the event */
        g_dropped++;
        pthread_mutex_unlock(&g_log_mutex);
        return;
    }
    if (g_processed == g_posted) g_thr_n = 0;  /* logger idle: forget old trace lines */
    g_queue[g_q_tail] = ev;
    g_q_tail = (g_q_tail + 1) % LOG_QUEUE;
    g_q_count++;
    g_posted++;
    g_last_seq = g_posted;
    snprintf(g_last_text, sizeof g_last_text, "%s", ev.text);
    pthread_mutex_unlock(&g_log_mutex);

    sem_post(&g_log_sem);                      /* notify the logger thread */
}

/* Wait until the logger thread has written every queued event. */
static void wait_logger_idle(void)
{
    if (!g_logger_started) return;
    pthread_mutex_lock(&g_log_mutex);
    while (g_processed < g_posted)
        pthread_cond_wait(&g_idle_cond, &g_log_mutex);
    pthread_mutex_unlock(&g_log_mutex);
}

/* Learning Mode: show what the main thread and the logger thread just did. */
static void trace_thread_view(void)
{
    char lines[THR_LINES][THR_LEN], text[LOG_TEXT];
    int count, i;
    long seq;

    if (!g_learning || !g_logger_started) return;
    wait_logger_idle();

    pthread_mutex_lock(&g_log_mutex);
    count = g_thr_n;
    for (i = 0; i < count; i++) memcpy(lines[i], g_thr_trace[i], THR_LEN);
    g_thr_n = 0;
    seq = g_last_seq;
    snprintf(text, sizeof text, "%s", g_last_text);
    pthread_mutex_unlock(&g_log_mutex);

    trace_heading("CO-6: Concurrency View (logger thread + mutex + semaphore)");
    trace_real("[Main Thread  ] queued log event #%ld, then called sem_post(): \"%s\"", seq, text);
    for (i = 0; i < count; i++) trace_real("%s", lines[i]);
    trace_concept("Without the mutex, two writers could mix their text inside audit.log.");
}

/* start the logger: open audit.log, create the semaphore and the thread */
static void logger_start(void)
{
    sigset_t block, old;

    g_audit_fd = open("audit.log", O_WRONLY | O_CREAT | O_APPEND, 0644);
    if (g_audit_fd == -1) {
        printf("WARNING: cannot open audit.log (%s). Logging is disabled.\n", strerror(errno));
        return;
    }
    /* Move the log descriptor up to FD 10 or higher (fcntl + F_DUPFD) so the
     * low numbers 3, 4, 5... stay free for the files YOU open. */
    int high_fd = fcntl(g_audit_fd, F_DUPFD, 10);
    if (high_fd != -1) {
        close(g_audit_fd);
        g_audit_fd = high_fd;
    }
    if (sem_init(&g_log_sem, 0, 0) == -1) {
        printf("WARNING: sem_init failed (%s). Logging is disabled.\n", strerror(errno));
        close(g_audit_fd);
        g_audit_fd = -1;
        return;
    }

    /* Block SIGINT/SIGCHLD while creating the thread, so the signals are
     * always handled by the MAIN thread (the thread inherits the mask). */
    sigemptyset(&block);
    sigaddset(&block, SIGINT);
    sigaddset(&block, SIGCHLD);
    pthread_sigmask(SIG_BLOCK, &block, &old);
    int rc = pthread_create(&g_logger, NULL, logger_main, NULL);
    pthread_sigmask(SIG_SETMASK, &old, NULL);

    if (rc != 0) {
        printf("WARNING: pthread_create failed (%s). Logging is disabled.\n", strerror(rc));
        sem_destroy(&g_log_sem);
        close(g_audit_fd);
        g_audit_fd = -1;
        return;
    }
    g_logger_started = 1;
}

/* stop the logger cleanly and release everything */
static void logger_stop(void)
{
    if (!g_logger_started) return;
    wait_logger_idle();

    pthread_mutex_lock(&g_log_mutex);
    g_log_quit = 1;
    pthread_mutex_unlock(&g_log_mutex);
    sem_post(&g_log_sem);                      /* wake the thread so it can leave */
    pthread_join(g_logger, NULL);
    g_logger_started = 0;

    sem_destroy(&g_log_sem);
    pthread_cond_destroy(&g_idle_cond);
    pthread_mutex_destroy(&g_log_mutex);
    if (g_audit_fd != -1) {
        if (close(g_audit_fd) == -1) perror("close(audit.log)");
        g_audit_fd = -1;
    }
}

/* ======================================================================
 * Descriptor bookkeeping and small file helpers
 * ====================================================================== */
static Slot *slot_find(int fd)
{
    for (int i = 0; i < MAX_FILES; i++)
        if (g_slots[i].fd == fd && fd >= 0) return &g_slots[i];
    return NULL;
}

static int tracked_count(void)
{
    int n = 0;
    for (int i = 0; i < MAX_FILES; i++) if (g_slots[i].fd != -1) n++;
    return n;
}

static Slot *slot_add(int fd, const char *name, int group)
{
    for (int i = 0; i < MAX_FILES; i++) {
        if (g_slots[i].fd == -1) {
            g_slots[i].fd = fd;
            g_slots[i].group = group;
            snprintf(g_slots[i].name, sizeof g_slots[i].name, "%s", name);
            return &g_slots[i];
        }
    }
    return NULL;
}

static void slot_remove(Slot *s)
{
    s->fd = -1;
    s->group = 0;
    s->name[0] = '\0';
}

static int group_members(int group, int except_fd)
{
    int n = 0;
    for (int i = 0; i < MAX_FILES; i++)
        if (g_slots[i].fd != -1 && g_slots[i].group == group && g_slots[i].fd != except_fd) n++;
    return n;
}

static void list_tracked(void)
{
    for (int i = 0; i < MAX_FILES; i++)
        if (g_slots[i].fd != -1)
            printf("   FD %-3d -> %s\n", g_slots[i].fd, g_slots[i].name);
}

/* Which descriptor should the operation use? Returns the FD or -1. */
static int choose_fd(const char *purpose)
{
    long fd;
    char prompt[96];
    int n = tracked_count();

    if (n == 0) {
        printf("No file is open. Choose option 2 (Open/Create file) first.\n");
        return -1;
    }
    if (n == 1) {
        for (int i = 0; i < MAX_FILES; i++) {
            if (g_slots[i].fd != -1) {
                printf("(using FD %d: %s)\n", g_slots[i].fd, g_slots[i].name);
                return g_slots[i].fd;
            }
        }
    }
    printf("Open descriptors:\n");
    list_tracked();
    snprintf(prompt, sizeof prompt, "Which FD for %s? ", purpose);
    if (read_number(prompt, &fd) != 0) return -1;
    if (fd < 0 || fd > INT_MAX || slot_find((int)fd) == NULL) {
        printf("FD %ld is not in the list above.\n", fd);
        return -1;
    }
    return (int)fd;
}

/* current file offset: lseek(fd, 0, SEEK_CUR) moves nothing, it only reports */
static off_t fd_offset(int fd)
{
    return lseek(fd, 0, SEEK_CUR);
}

/* ask the kernel how a descriptor was opened (fcntl + F_GETFL) */
static const char *access_mode_name(int fd)
{
    int flags = fcntl(fd, F_GETFL);

    if (flags == -1) return "unknown";
    switch (flags & O_ACCMODE) {
    case O_RDONLY: return "Read only";
    case O_WRONLY: return "Write only";
    case O_RDWR:   return "Read and Write";
    default:       return "unknown";
    }
}

/* what does a descriptor point to? The kernel tells us through /proc */
static void fd_target(int fd, char *out, size_t size)
{
    char link[64];
    ssize_t n;

    snprintf(link, sizeof link, "/proc/self/fd/%d", fd);
    n = readlink(link, out, size - 1);
    if (n == -1) snprintf(out, size, "?");
    else out[n] = '\0';
}

static const char *fd_note(int fd)
{
    static char buf[PATH_LEN + 32];
    Slot *s;

    if (fd <= 2) return "standard stream";
    if (fd == g_audit_fd) return "logger thread's audit.log";
    if (fd == g_pipe_cmd[0]) return "command pipe, READ end (parent -> child)";
    if (fd == g_pipe_cmd[1]) return "command pipe, WRITE end (parent -> child)";
    if (fd == g_pipe_res[0]) return "result pipe, READ end (child -> parent)";
    if (fd == g_pipe_res[1]) return "result pipe, WRITE end (child -> parent)";
    s = slot_find(fd);
    if (s) {
        snprintf(buf, sizeof buf, "opened by you: %s", s->name);
        return buf;
    }
    return "";
}

/* REAL table of the descriptors of THIS process, taken from /proc/self/fd */
static void print_fd_table(void)
{
    DIR *dir = opendir("/proc/self/fd");
    int fds[256], n = 0, own;
    struct dirent *e;

    if (!dir) {
        report_error("opendir(/proc/self/fd)", errno);
        return;
    }
    own = dirfd(dir);
    while ((e = readdir(dir)) != NULL && n < 256) {
        if (e->d_name[0] == '.') continue;
        int fd = atoi(e->d_name);
        if (fd != own) fds[n++] = fd;          /* hide the descriptor opendir() uses */
    }
    closedir(dir);

    for (int i = 1; i < n; i++) {              /* sort ascending (insertion sort) */
        int key = fds[i], j = i - 1;
        while (j >= 0 && fds[j] > key) { fds[j + 1] = fds[j]; j--; }
        fds[j + 1] = key;
    }

    printf("  +------+----------------------------------+----------------+-------------+\n");
    printf("  | FD   | Resource (from /proc/self/fd)    | Access mode    | File offset |\n");
    printf("  +------+----------------------------------+----------------+-------------+\n");
    for (int i = 0; i < n; i++) {
        char target[PATH_LEN], shown[40], offtxt[24];
        size_t len;
        off_t off;

        fd_target(fds[i], target, sizeof target);
        len = strlen(target);
        if (len > 32) snprintf(shown, sizeof shown, "...%s", target + len - 29);
        else snprintf(shown, sizeof shown, "%.32s", target);

        off = lseek(fds[i], 0, SEEK_CUR);
        if (off == (off_t)-1) snprintf(offtxt, sizeof offtxt, "N/A");
        else snprintf(offtxt, sizeof offtxt, "%lld", (long long)off);

        printf("  | %-4d | %-32s | %-14s | %-11s |  %s\n", fds[i], shown,
               access_mode_name(fds[i]), offtxt, fd_note(fds[i]));
    }
    printf("  +------+----------------------------------+----------------+-------------+\n");
    printf("  (offset N/A = terminals and pipes have no file offset)\n");
    fflush(stdout);
}

/* ======================================================================
 * Option 1 and 13: Basic Mode / Learning Mode
 * ====================================================================== */
static void select_mode(void)
{
    long choice;

    printf("\nSelect mode:\n");
    printf("  1. Basic Mode    - show only the results\n");
    printf("  2. Learning Mode - show the Internal Execution Trace\n");
    if (read_number("Choice: ", &choice) != 0) return;

    if (choice == 1) {
        g_learning = 0;
        printf("Basic Mode selected.\n");
    } else if (choice == 2) {
        g_learning = 1;
        printf("Learning Mode selected. Every operation will now explain what happens internally.\n");
    } else {
        printf("Invalid choice. Mode not changed.\n");
    }
}

static void toggle_trace(void)
{
    g_learning = !g_learning;
    printf("Internal Execution Trace is now %s.\n", g_learning ? "ENABLED (Learning Mode)" : "DISABLED (Basic Mode)");
}

/* ======================================================================
 * Option 2: open() / create a file                                  CO-1, CO-5
 * ====================================================================== */
static void action_open(void)
{
    char path[PATH_LEN];
    long choice;
    int flags;
    const char *flag_text;

    if (tracked_count() >= MAX_FILES) {
        printf("Too many files are open (maximum %d). Close one first (option 14).\n", MAX_FILES);
        return;
    }
    if (read_line("File name (example: notes.txt): ", path, sizeof path) != 0) return;
    if (path[0] == '\0') {
        printf("File name cannot be empty.\n");
        return;
    }

    printf("Access mode:\n");
    printf("  1. Read only\n");
    printf("  2. Write only   (create the file if it does not exist)\n");
    printf("  3. Read + Write (create the file if it does not exist)\n");
    if (read_number("Choice: ", &choice) != 0) return;

    switch (choice) {
    case 1: flags = O_RDONLY;           flag_text = "O_RDONLY";           break;
    case 2: flags = O_WRONLY | O_CREAT; flag_text = "O_WRONLY | O_CREAT"; break;
    case 3: flags = O_RDWR   | O_CREAT; flag_text = "O_RDWR | O_CREAT";   break;
    default:
        printf("Invalid choice.\n");
        return;
    }

    /* real information: did the file exist before open()? */
    int existed = (access(path, F_OK) == 0);

    trace_begin("open()");
    trace_heading("CO-1: User Space to Kernel Space");
    trace_concept("1. You selected the 'Open/Create file' option.");
    trace_real   ("2. This C program runs in USER SPACE as process PID %d.", (int)getpid());
    trace_concept("3. User space may not touch files or disks directly.");
    trace_concept("4. So the program requests a kernel service using a system call:");
    trace_line("\nSystem call requested:");
    trace_line("  open(\"%s\", %s, 0644)", path, flag_text);

    int fd = open(path, flags, 0644);
    if (fd == -1) {
        int err = errno;
        report_error("open()", err);
        log_event("open(\"%s\") FAILED: %s", path, strerror(err));
        trace_heading("CO-5: File Descriptor and File System View");
        trace_real   ("open() returned -1, errno = %d (%s)", err, strerror(err));
        trace_concept("The kernel refused the request (for example: file missing or no permission).");
        trace_concept("No open file description was created and no descriptor number was allocated.");
        trace_thread_view();
        trace_end();
        return;
    }

    slot_add(fd, path, g_next_group++);
    stat_add(&g_stats->files_opened, 1);

    struct stat st;
    int have_stat = (fstat(fd, &st) == 0);       /* real inode information */

    log_event("open(\"%s\", %s) -> FD %d, mode %s", path, flag_text, fd, access_mode_name(fd));

    if (!g_learning) {
        printf("File \"%s\" opened. FD = %d, access mode = %s.\n", path, fd, access_mode_name(fd));
        return;
    }

    trace_heading("CO-5: File Descriptor and File System View");
    trace_concept("5. Linux checks the pathname and your permissions.");
    trace_concept("6. The VFS (Virtual File System) conceptually finds which mounted filesystem holds the file.");
    trace_concept("7. The filesystem locates the file's inode (or, with O_CREAT, creates it).");
    trace_concept("8. The kernel creates an OPEN FILE DESCRIPTION (it stores the access mode and the file offset).");
    trace_concept("9. The kernel returns the lowest free descriptor number to this process.");

    printf("\nReal runtime result:\n");
    trace_real("File existed before open(): %s   (checked with access())", existed ? "yes" : "no, it was created");
    trace_real("File descriptor allocated : %d", fd);
    trace_real("Initial file offset       : %lld   (from lseek(fd, 0, SEEK_CUR))", (long long)fd_offset(fd));
    trace_real("Access mode (kernel says) : %s   (from fcntl(fd, F_GETFL))", access_mode_name(fd));
    if (have_stat) {
        trace_real("Inode number              : %llu   (from fstat)", (unsigned long long)st.st_ino);
        trace_real("File size                 : %lld bytes   permissions: %03o", (long long)st.st_size, (unsigned)(st.st_mode & 0777));
    }

    printf("\nDescriptor table of this process (conceptual view):\n");
    printf("  FD 0  ->  Standard Input   ->  Terminal   [normal when started from a shell]\n");
    printf("  FD 1  ->  Standard Output  ->  Terminal   [normal when started from a shell]\n");
    printf("  FD 2  ->  Standard Error   ->  Terminal   [normal when started from a shell]\n");
    printf("  FD %d  ->  %s  ->  Open File Description\n", fd, path);

    printf("\nConceptual relationship:\n");
    printf("  FD %d\n   |\n   v\n  Process File Descriptor Table\n   |\n   v\n  Open File Description (mode + offset)\n   |\n   v\n  Inode\n   |\n   v\n  %s file data\n", fd, path);
    trace_thread_view();
    trace_end();
}

/* ======================================================================
 * Option 3: write()                                                 CO-1, CO-4, CO-5
 * ====================================================================== */
static void do_write(int fd, const char *text, size_t len)
{
    Slot *slot = slot_find(fd);
    off_t before = fd_offset(fd);

    trace_begin("write()");
    trace_heading("CO-1: User Space to Kernel Space");
    trace_concept("1. You selected 'Write text to file'.");
    trace_real   ("2. The text lives in a malloc() buffer in user-space memory (%zu bytes, newline included).", len);
    trace_concept("3. The program asks the kernel to copy those bytes into the file:");
    trace_line("\nSystem call requested:");
    trace_line("  write(%d, buffer, %zu)", fd, len);

    ssize_t n = write(fd, text, len);
    if (n == -1) {
        int err = errno;
        report_error("write()", err);
        log_event("write(FD %d) FAILED: %s", fd, strerror(err));
        trace_heading("CO-5: File Descriptor and File System View");
        trace_real   ("write() returned -1, errno = %d (%s)", err, strerror(err));
        trace_concept("The kernel checked the open file description and refused the write");
        trace_concept("(for example: the file was opened Read only, so writing is not allowed).");
        trace_thread_view();
        trace_end();
        return;
    }

    off_t after = fd_offset(fd);
    stat_add(&g_stats->writes, 1);
    stat_add(&g_stats->bytes_written, (long)n);
    log_event("write(FD %d, %s): %zd bytes, offset %lld -> %lld", fd, slot ? slot->name : "?", n,
              (long long)before, (long long)after);

    if (!g_learning) {
        printf("Wrote %zd bytes to FD %d. Offset: %lld -> %lld.\n", n, fd, (long long)before, (long long)after);
        return;
    }

    trace_heading("CO-5: File Descriptor and File System View");
    trace_concept("4. The kernel looks up FD %d in this process's descriptor table.", fd);
    trace_concept("5. That entry points to an open file description, which says the file is open for writing.");
    trace_concept("6. The kernel writes at the offset stored in that open file description.");
    trace_concept("7. Through the VFS, the filesystem stores the bytes (normally in the page cache first;");
    trace_concept("   the physical disk may be updated later).");
    trace_concept("8. The kernel moves the offset forward and returns the number of bytes written.");

    printf("\nReal runtime result:\n");
    trace_real("Bytes requested : %zu", len);
    trace_real("Bytes written   : %zd", n);
    trace_real("Offset before   : %lld", (long long)before);
    trace_real("Offset after    : %lld", (long long)after);
    if ((size_t)n < len)
        trace_real("Only part of the data was written (a 'short write').");
    trace_thread_view();
    trace_end();
}

static void action_write(void)
{
    int fd = choose_fd("writing");
    if (fd < 0) return;

    char *text = malloc(LINE_LEN);               /* CO-4: input buffer on the heap */
    if (text == NULL) {
        report_error("malloc()", errno);
        return;
    }
    if (read_line("Text to write: ", text, LINE_LEN - 1) != 0) {
        free(text);
        return;
    }
    size_t len = strlen(text);
    if (len == 0) {
        printf("Nothing to write (empty text).\n");
        free(text);
        return;
    }
    text[len++] = '\n';                          /* end the line */
    text[len] = '\0';

    do_write(fd, text, len);
    free(text);
}

/* ======================================================================
 * Option 4: read()                                                  CO-1, CO-4, CO-5
 * ====================================================================== */
static void action_read(void)
{
    long count;
    int fd = choose_fd("reading");

    if (fd < 0) return;
    if (read_number("How many bytes to read (1-1000): ", &count) != 0) return;
    if (count < 1 || count > MAX_READ) {
        printf("Please choose a number from 1 to %d.\n", MAX_READ);
        return;
    }

    char *buffer = malloc((size_t)count + 1);    /* +1 for the final '\0' */
    if (buffer == NULL) {
        report_error("malloc()", errno);
        return;
    }

    Slot *slot = slot_find(fd);
    off_t before = fd_offset(fd);

    trace_begin("read()");
    trace_heading("CO-1: User Space to Kernel Space");
    trace_concept("1. You selected 'Read file content'.");
    trace_real   ("2. Our buffer was created with malloc() in the user-space heap.");
    trace_real   ("   Its virtual address is %p (a virtual address, not a physical RAM address).", (void *)buffer);
    trace_concept("3. The program asks the kernel to fill that buffer from the file:");
    trace_line("\nSystem call requested:");
    trace_line("  read(%d, buffer, %ld)", fd, count);

    ssize_t n = read(fd, buffer, (size_t)count);
    if (n == -1) {
        int err = errno;
        report_error("read()", err);
        log_event("read(FD %d) FAILED: %s", fd, strerror(err));
        trace_heading("CO-5: File Descriptor and File System View");
        trace_real   ("read() returned -1, errno = %d (%s)", err, strerror(err));
        trace_concept("The kernel refused the read (for example: the file was opened Write only).");
        trace_thread_view();
        trace_end();
        free(buffer);
        return;
    }
    buffer[n] = '\0';

    off_t after = fd_offset(fd);
    stat_add(&g_stats->reads, 1);
    stat_add(&g_stats->bytes_read, (long)n);
    log_event("read(FD %d, %s): %zd bytes, offset %lld -> %lld", fd, slot ? slot->name : "?", n,
              (long long)before, (long long)after);

    if (!g_learning) {
        if (n == 0)
            printf("Read 0 bytes: end of file reached (offset %lld).\n", (long long)after);
        else
            printf("Read %zd bytes from FD %d:\n%s\n", n, fd, buffer);
        free(buffer);
        return;
    }

    trace_heading("CO-5: File Descriptor and File System View");
    trace_concept("4. The kernel looks up FD %d in the descriptor table and finds the open file description.", fd);
    trace_concept("5. It reads starting at the current offset stored there.");
    trace_concept("6. Through the VFS, the filesystem supplies the data (from the page cache or the disk).");
    trace_concept("7. The kernel copies the bytes into our user-space buffer and moves the offset forward.");

    printf("\nReal runtime result:\n");
    trace_real("Bytes requested : %ld", count);
    trace_real("Bytes read      : %zd", n);
    trace_real("Offset before   : %lld", (long long)before);
    trace_real("Offset after    : %lld", (long long)after);
    if (n == 0)
        trace_concept("read() returned 0 = END OF FILE: the offset is at the end. Use lseek() to go back.");
    else
        printf("\nData read:\n%s\n", buffer);
    trace_thread_view();
    trace_end();

    free(buffer);
}

/* ======================================================================
 * Option 5: lseek()                                                 CO-1, CO-5
 * ====================================================================== */
static void action_lseek(void)
{
    long choice, amount;
    int whence;
    const char *whence_text;
    int fd = choose_fd("seeking");

    if (fd < 0) return;

    printf("Move the offset relative to:\n");
    printf("  1. SEEK_SET - start of the file\n");
    printf("  2. SEEK_CUR - current position\n");
    printf("  3. SEEK_END - end of the file\n");
    if (read_number("Choice: ", &choice) != 0) return;

    switch (choice) {
    case 1: whence = SEEK_SET; whence_text = "SEEK_SET"; break;
    case 2: whence = SEEK_CUR; whence_text = "SEEK_CUR"; break;
    case 3: whence = SEEK_END; whence_text = "SEEK_END"; break;
    default:
        printf("Invalid choice.\n");
        return;
    }
    if (read_number("Number of bytes to move (can be negative): ", &amount) != 0) return;

    off_t before = fd_offset(fd);

    trace_begin("lseek()");
    trace_heading("CO-1: User Space to Kernel Space");
    trace_concept("1. You selected 'Move file offset'.");
    trace_concept("2. The offset is kept by the kernel, so the program must ask the kernel to change it:");
    trace_line("\nSystem call requested:");
    trace_line("  lseek(%d, %ld, %s)", fd, amount, whence_text);

    off_t result = lseek(fd, (off_t)amount, whence);
    if (result == (off_t)-1) {
        int err = errno;
        report_error("lseek()", err);
        log_event("lseek(FD %d, %ld, %s) FAILED: %s", fd, amount, whence_text, strerror(err));
        trace_heading("CO-5: File Descriptor and File System View");
        trace_real   ("lseek() returned -1, errno = %d (%s)", err, strerror(err));
        trace_concept("The kernel refused: the resulting offset would be invalid (for example negative).");
        trace_thread_view();
        trace_end();
        return;
    }

    log_event("lseek(FD %d, %ld, %s): offset %lld -> %lld", fd, amount, whence_text, (long long)before, (long long)result);

    if (!g_learning) {
        printf("Offset moved: %lld -> %lld.\n", (long long)before, (long long)result);
        return;
    }

    trace_heading("CO-5: File Descriptor and File System View");
    trace_concept("3. The kernel finds the open file description behind FD %d.", fd);
    trace_concept("4. It changes ONLY the offset stored there. No data is read or written, no disk access happens.");
    trace_concept("5. The next read() or write() will start at the new offset.");

    printf("\nReal runtime result:\n");
    trace_real("Offset before : %lld", (long long)before);
    trace_real("Offset after  : %lld", (long long)result);
    trace_thread_view();
    trace_end();
}

/* ======================================================================
 * Option 6: display the current offset                              CO-5
 * ====================================================================== */
static void action_show_offset(void)
{
    int fd = choose_fd("the offset");
    if (fd < 0) return;
    Slot *slot = slot_find(fd);

    trace_begin("lseek(fd, 0, SEEK_CUR)");
    trace_heading("CO-5: File Descriptor and File System View");
    trace_concept("lseek() with offset 0 and SEEK_CUR changes nothing; it only reports the current offset.");
    trace_line("\nSystem call requested:");
    trace_line("  lseek(%d, 0, SEEK_CUR)", fd);

    off_t pos = fd_offset(fd);
    if (pos == (off_t)-1) {
        report_error("lseek()", errno);
        trace_end();
        return;
    }
    printf("Current offset of FD %d (\"%s\"): %lld bytes from the start.\n", fd, slot ? slot->name : "?", (long long)pos);
    log_event("offset query FD %d: %lld", fd, (long long)pos);

    if (slot && group_members(slot->group, fd) > 0) {
        for (int i = 0; i < MAX_FILES; i++) {
            if (g_slots[i].fd != -1 && g_slots[i].group == slot->group && g_slots[i].fd != fd)
                trace_real("FD %d shares the same open file description, so its offset is also %lld.",
                           g_slots[i].fd, (long long)fd_offset(g_slots[i].fd));
        }
    }
    trace_concept("The offset is stored in the open file description, not in this program.");
    trace_thread_view();
    trace_end();
}

/* ======================================================================
 * Option 14: close()                                                CO-1, CO-5
 * ====================================================================== */
static void action_close(void)
{
    int fd = choose_fd("closing");
    if (fd < 0) return;

    Slot *slot = slot_find(fd);
    char name[PATH_LEN];
    snprintf(name, sizeof name, "%s", slot->name);
    int group = slot->group;
    int others = group_members(group, fd);       /* descriptors sharing the same description */

    trace_begin("close()");
    trace_heading("CO-1: User Space to Kernel Space");
    trace_concept("1. You selected 'Close descriptor'.");
    trace_concept("2. The program asks the kernel to release the descriptor:");
    trace_line("\nSystem call requested:");
    trace_line("  close(%d)", fd);

    int rc = close(fd);
    int err = errno;

    /* On Linux the descriptor is released even if close() reports an error,
     * so the program must not use or close this number again. */
    slot_remove(slot);

    if (rc == -1) {
        report_error("close()", err);
        log_event("close(FD %d) FAILED: %s", fd, strerror(err));
        trace_real("close() returned -1, errno = %d (%s)", err, strerror(err));
        trace_thread_view();
        trace_end();
        return;
    }
    log_event("close(FD %d, %s)", fd, name);

    if (!g_learning) {
        printf("FD %d closed.\n", fd);
        return;
    }

    trace_heading("CO-5: File Descriptor and File System View");
    trace_concept("3. The kernel removes FD %d from this process's descriptor table.", fd);
    trace_concept("4. It lowers the reference count of the open file description.");
    trace_concept("5. When no descriptor refers to it any more, the open file description is freed.");
    trace_concept("6. The number %d becomes free again; the next open() can reuse it.", fd);
    trace_concept("Note: close() does not force data onto the disk (that is what fsync() is for),");
    trace_concept("but not closing files wastes descriptors (a 'descriptor leak').");

    printf("\nReal runtime result:\n");
    trace_real("close(%d) returned 0 = success", fd);
    if (others > 0)
        trace_real("%d other descriptor(s) still refer to the same open file description, so it stays alive.", others);
    else
        trace_real("No other descriptor shared it, so the open file description is now released.");
    trace_thread_view();
    trace_end();
}

/* ======================================================================
 * Option 7: show active file descriptors                           CO-1, CO-5
 * ====================================================================== */
static void action_fd_table(void)
{
    trace_begin("active file descriptors");
    trace_heading("CO-1: User Space to Kernel Space");
    trace_concept("1. The kernel publishes information about every process in /proc (a virtual filesystem).");
    trace_concept("2. This program reads /proc/self/fd and asks the kernel about each descriptor:");
    trace_line("\nSystem calls used:");
    trace_line("  opendir(\"/proc/self/fd\"), readlink(), fcntl(fd, F_GETFL), lseek(fd, 0, SEEK_CUR)");

    printf("\nFile descriptor table of process PID %d:\n", (int)getpid());
    print_fd_table();
    log_event("showed the descriptor table");

    if (g_learning) {
        trace_heading("CO-5: File Descriptor and File System View");
        trace_real   ("Every row above was reported by the kernel for THIS process.");
        trace_concept("Relationship for any row:");
        trace_line("  FD  ->  Process File Descriptor Table  ->  Open File Description  ->  Inode  ->  file data");
        trace_concept("The open file description and inode themselves are kernel memory; we only see the results.");
        trace_thread_view();
    }
    trace_end();
}

/* ======================================================================
 * Option 8: dup()                                                   CO-1, CO-5
 * ====================================================================== */
static void dup_demo(int fd, int newfd)
{
    char buf[6];
    ssize_t n;

    if ((fcntl(fd, F_GETFL) & O_ACCMODE) == O_WRONLY) {
        printf("This file is Write only, so the read demo is skipped.\n");
        return;
    }
    printf("\nShared-offset demo: read 5 bytes through FD %d, then 5 bytes through FD %d\n", fd, newfd);

    off_t before = fd_offset(fd);
    n = read(fd, buf, 5);
    if (n == -1) { report_error("read()", errno); return; }
    buf[n] = '\0';
    stat_add(&g_stats->reads, 1);
    stat_add(&g_stats->bytes_read, (long)n);
    printf("  read through FD %d: \"%s\"   offset %lld -> %lld\n", fd, buf, (long long)before, (long long)fd_offset(fd));

    before = fd_offset(newfd);
    n = read(newfd, buf, 5);
    if (n == -1) { report_error("read()", errno); return; }
    buf[n] = '\0';
    stat_add(&g_stats->reads, 1);
    stat_add(&g_stats->bytes_read, (long)n);
    printf("  read through FD %d: \"%s\"   offset %lld -> %lld\n", newfd, buf, (long long)before, (long long)fd_offset(newfd));
    printf("The second read CONTINUED where the first stopped: both descriptors share one offset.\n");
    printf("(If the file is shorter than 10 bytes you may see empty data: that is end of file.)\n");
    log_event("dup demo: read 5+5 bytes through FD %d and FD %d", fd, newfd);
}

static void action_dup(void)
{
    int fd = choose_fd("duplicating");
    if (fd < 0) return;
    if (tracked_count() >= MAX_FILES) {
        printf("Too many files are open (maximum %d). Close one first.\n", MAX_FILES);
        return;
    }
    Slot *src = slot_find(fd);
    char label[PATH_LEN + 32];
    snprintf(label, sizeof label, "%s (dup of FD %d)", src->name, fd);
    int group = src->group;

    trace_begin("dup()");
    trace_heading("CO-1: User Space to Kernel Space");
    trace_concept("1. You selected 'Duplicate descriptor'.");
    trace_concept("2. The program asks the kernel for a second descriptor number for the same open file:");
    trace_line("\nSystem call requested:");
    trace_line("  dup(%d)", fd);

    int newfd = dup(fd);
    if (newfd == -1) {
        int err = errno;
        report_error("dup()", err);
        log_event("dup(FD %d) FAILED: %s", fd, strerror(err));
        trace_thread_view();
        trace_end();
        return;
    }
    slot_add(newfd, label, group);
    log_event("dup(FD %d) -> FD %d (same open file description)", fd, newfd);

    printf("dup() succeeded: original FD %d, new FD %d.\n", fd, newfd);

    if (g_learning) {
        trace_heading("CO-5: File Descriptor and File System View");
        trace_concept("3. The kernel finds the open file description behind FD %d.", fd);
        trace_concept("4. It does NOT create a new one; it adds a second descriptor-table entry pointing to the same one.");
        printf("\nReal runtime result:\n");
        trace_real("Original descriptor : FD %d", fd);
        trace_real("New descriptor      : FD %d   (lowest free number)", newfd);
        trace_real("Offset seen through FD %d : %lld", fd, (long long)fd_offset(fd));
        trace_real("Offset seen through FD %d : %lld   (always equal: ONE shared offset)", newfd, (long long)fd_offset(newfd));
        printf("\nConceptual relationship:\n");
        printf("  FD %d ---+\n", fd);
        printf("           +--> Open File Description (mode + offset) --> Inode --> %s\n", src->name);
        printf("  FD %d ---+\n", newfd);
        trace_thread_view();
    }
    trace_end();

    long ask;
    if (read_number("\nRun the shared-offset read demo? (1 = yes, 0 = no): ", &ask) == 0 && ask == 1)
        dup_demo(fd, newfd);
}

/* ======================================================================
 * Option 9: dup2() - redirect stdout into a file                    CO-1, CO-5
 * ====================================================================== */
static void action_dup2(void)
{
    char text[LINE_LEN];
    int fd = choose_fd("receiving stdout");

    if (fd < 0) return;
    if ((fcntl(fd, F_GETFL) & O_ACCMODE) == O_RDONLY) {
        printf("FD %d is Read only. Open a file with Write or Read+Write mode first.\n", fd);
        return;
    }
    Slot *slot = slot_find(fd);
    if (read_line("Text to print while stdout is redirected: ", text, sizeof text - 1) != 0) return;
    if (text[0] == '\0') {
        printf("Nothing to print.\n");
        return;
    }

    char before[PATH_LEN], during[PATH_LEN], after[PATH_LEN];
    off_t off_before = fd_offset(fd);

    trace_begin("dup2() stdout redirection");
    trace_heading("CO-1: User Space to Kernel Space");
    trace_concept("1. You selected 'Redirect stdout using dup2()'. This is how a shell implements:  command > file");
    trace_concept("2. The program uses these system calls:");
    trace_line("\nSystem calls requested:");
    trace_line("  saved = dup(1)        keep a copy of the terminal descriptor");
    trace_line("  dup2(%d, 1)            make FD 1 point to the file", fd);
    trace_line("  ... printf() now writes into the file ...");
    trace_line("  dup2(saved, 1)        restore FD 1 to the terminal");

    fd_target(STDOUT_FILENO, before, sizeof before);

    fflush(stdout);                              /* flush BEFORE changing FD 1 */
    int saved = dup(STDOUT_FILENO);
    if (saved == -1) {
        int err = errno;
        report_error("dup()", err);
        log_event("dup2 redirect: dup(1) FAILED: %s", strerror(err));
        trace_end();
        return;
    }
    if (dup2(fd, STDOUT_FILENO) == -1) {
        int err = errno;
        close(saved);
        report_error("dup2()", err);
        log_event("dup2(FD %d, 1) FAILED: %s", fd, strerror(err));
        trace_end();
        return;
    }

    /* ---- from here until the restore, stdout is the FILE; print nothing else ---- */
    fd_target(STDOUT_FILENO, during, sizeof during);
    printf("%s\n", text);
    fflush(stdout);
    if (dup2(saved, STDOUT_FILENO) == -1) {       /* restore the terminal */
        perror("dup2(restore)");
        _exit(1);                                /* stdout is lost: nothing safe left to do */
    }
    close(saved);
    /* ---- stdout is the terminal again ---- */

    fd_target(STDOUT_FILENO, after, sizeof after);
    off_t off_after = fd_offset(fd);
    stat_add(&g_stats->writes, 1);
    stat_add(&g_stats->bytes_written, (long)strlen(text) + 1);
    log_event("dup2 redirect: \"%s\" written to FD %d (%s) through stdout", text, fd, slot ? slot->name : "?");

    printf("The text was sent to the file %s instead of the screen.\n", slot ? slot->name : "?");
    printf("Tip: use option 5 to rewind and option 4 to read it back.\n");

    if (g_learning) {
        trace_heading("CO-5: File Descriptor and File System View");
        trace_concept("3. dup2(fd, 1) closes FD 1 and makes it refer to the SAME open file description as fd.");
        trace_concept("4. printf() still writes to 'FD 1'; it does not know the target changed.");
        printf("\nReal runtime result (read from /proc/self/fd/1):\n");
        trace_real("FD 1 BEFORE the redirect : %s", before);
        trace_real("FD 1 DURING the redirect : %s", during);
        trace_real("FD 1 AFTER the restore   : %s", after);
        trace_real("Offset of FD %d before/after: %lld -> %lld", fd, (long long)off_before, (long long)off_after);
        trace_thread_view();
    }
    trace_end();
}

/* ======================================================================
 * Option 10: copy a file with a child process and two pipes
 *            CO-1 (fork, pipe, waitpid), CO-2 (processes), CO-3 (pipes, signals),
 *            CO-4 (shared mmap statistics), CO-5 (file I/O)
 * ====================================================================== */

/* the child could not finish: tell the parent, then leave */
__attribute__((noreturn)) static void child_fail(int res_write_fd, const char *what, int err)
{
    char msg[300];
    int len = snprintf(msg, sizeof msg, "ERROR: %s: %s", what, strerror(err));

    stat_add(&g_stats->errors, 1);
    g_stats->worker_status = WORKER_FAILED;
    if (write_all(res_write_fd, msg, (size_t)len) == -1) { /* parent gone: nothing to do */ }
    close(res_write_fd);
    fflush(stdout);
    _exit(1);
}

/* Everything the CHILD process does. It never returns. */
__attribute__((noreturn)) static void child_worker(void)
{
    char msg[2 * PATH_LEN + 16], src[PATH_LEN], dst[PATH_LEN];

    close(g_pipe_cmd[1]);                        /* the child only reads commands   */
    close(g_pipe_res[0]);                        /* the child only writes results   */

    ssize_t n = read_retry(g_pipe_cmd[0], msg, sizeof msg - 1);
    if (n <= 0) child_fail(g_pipe_res[1], "reading the command pipe", n == 0 ? EPIPE : errno);
    msg[n] = '\0';
    if (sscanf(msg, "COPY %255s %255s", src, dst) != 2) child_fail(g_pipe_res[1], "bad command", EINVAL);

    g_private_counter = 42;                      /* ordinary memory: only the CHILD's copy changes */

    if (g_learning) {
        printf("\n[CO-2/CO-3: running inside the CHILD process]\n");
        printf("  [REAL]    Child PID = %d, parent PID = %d\n", (int)getpid(), (int)getppid());
        printf("  [REAL]    Child read this command from the command pipe: \"%s\"\n", msg);
        printf("  [REAL]    Child set its own g_private_counter = %d and sees the shared stats at %p\n",
               g_private_counter, (void *)g_stats);
        printf("  [CONCEPT] fork() copied the parent's descriptors, so the child owns copies of them too:\n");
        printf("\n  Descriptor table of the CHILD (PID %d):\n", (int)getpid());
        print_fd_table();
        fflush(stdout);
    }

    int in = open(src, O_RDONLY);
    if (in == -1) child_fail(g_pipe_res[1], "open(source)", errno);
    stat_add(&g_stats->files_opened, 1);

    int out = open(dst, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (out == -1) { int err = errno; close(in); child_fail(g_pipe_res[1], "open(destination)", err); }
    stat_add(&g_stats->files_opened, 1);

    char *buf = malloc(COPY_BUF);                /* CO-4: heap buffer for copying */
    if (buf == NULL) { close(in); close(out); child_fail(g_pipe_res[1], "malloc()", ENOMEM); }

    long total = 0;
    for (;;) {
        ssize_t got = read(in, buf, COPY_BUF);
        if (got == -1) {
            if (errno == EINTR) continue;
            int err = errno;
            free(buf); close(in); close(out);
            child_fail(g_pipe_res[1], "read()", err);
        }
        if (got == 0) break;                     /* end of file */
        stat_add(&g_stats->reads, 1);
        stat_add(&g_stats->bytes_read, (long)got);
        if (write_all(out, buf, (size_t)got) == -1) {
            int err = errno;
            free(buf); close(in); close(out);
            child_fail(g_pipe_res[1], "write()", err);
        }
        stat_add(&g_stats->writes, 1);
        stat_add(&g_stats->bytes_written, (long)got);
        total += got;
    }
    free(buf);
    if (close(in) == -1 || close(out) == -1) child_fail(g_pipe_res[1], "close()", errno);

    stat_add(&g_stats->copies_done, 1);
    g_stats->worker_status = WORKER_COMPLETED;

    char result[100];
    int len = snprintf(result, sizeof result, "SUCCESS: %ld bytes copied", total);
    if (write_all(g_pipe_res[1], result, (size_t)len) == -1) { /* parent gone */ }
    close(g_pipe_res[1]);
    close(g_pipe_cmd[0]);
    fflush(stdout);
    _exit(0);
}

static void action_copy(void)
{
    char src[PATH_LEN], dst[PATH_LEN];
    struct stat st_src, st_dst;

    if (read_line("Source file (no spaces in the name): ", src, sizeof src) != 0) return;
    if (read_line("Destination file (no spaces in the name): ", dst, sizeof dst) != 0) return;
    if (src[0] == '\0' || dst[0] == '\0' || strchr(src, ' ') || strchr(dst, ' ')) {
        printf("File names must not be empty or contain spaces.\n");
        return;
    }
    if (stat(src, &st_src) == -1) {
        report_error("stat(source)", errno);
        return;
    }
    if (!S_ISREG(st_src.st_mode)) {
        printf("The source must be a regular file.\n");
        return;
    }
    if (strcmp(src, dst) == 0 || (stat(dst, &st_dst) == 0 && st_dst.st_ino == st_src.st_ino && st_dst.st_dev == st_src.st_dev)) {
        printf("Source and destination are the same file. Choose a different destination.\n");
        return;
    }

    if (pipe(g_pipe_cmd) == -1) { report_error("pipe()", errno); return; }
    if (pipe(g_pipe_res) == -1) {
        int err = errno;
        close(g_pipe_cmd[0]); close(g_pipe_cmd[1]);
        g_pipe_cmd[0] = g_pipe_cmd[1] = -1;
        report_error("pipe()", err);
        return;
    }

    long before_bytes = g_stats->bytes_written;
    long sigchld_before = g_sigchld_count;
    g_private_counter = 0;
    g_stats->worker_status = WORKER_RUNNING;

    trace_begin("copy file with a child process and pipes");
    trace_heading("CO-1: User Space to Kernel Space");
    trace_concept("1. You selected 'Copy file using child process and pipes'.");
    trace_real   ("2. Source \"%s\": inode %llu, %lld bytes (from stat()).", src,
                  (unsigned long long)st_src.st_ino, (long long)st_src.st_size);
    trace_concept("3. System calls used: pipe(), pipe(), fork(), then open/read/write/close in the child, waitpid() in the parent.");

    trace_heading("CO-2: Process Execution View");
    trace_real   ("Parent PID: %d   (role: accept the command, wait, show the result)", (int)getpid());
    trace_line   ("\nAction:\n  fork() called");

    wait_logger_idle();                          /* make sure the logger thread is idle before fork() */
    fflush(stdout);
    pid_t pid = fork();
    if (pid == -1) {
        int err = errno;
        report_error("fork()", err);
        log_event("copy FAILED: fork(): %s", strerror(err));
        close(g_pipe_cmd[0]); close(g_pipe_cmd[1]); close(g_pipe_res[0]); close(g_pipe_res[1]);
        g_pipe_cmd[0] = g_pipe_cmd[1] = g_pipe_res[0] = g_pipe_res[1] = -1;
        g_stats->worker_status = WORKER_IDLE;
        trace_end();
        return;
    }
    if (pid == 0) child_worker();                /* the child never comes back */

    /* ---------------- parent ---------------- */
    int cmd_r = g_pipe_cmd[0], cmd_w = g_pipe_cmd[1], res_r = g_pipe_res[0], res_w = g_pipe_res[1];
    close(cmd_r);                                /* the parent only writes commands */
    close(res_w);                                /* the parent only reads results   */

    trace_real   ("New child process created: child PID %d, its parent PID %d", (int)pid, (int)getpid());
    trace_concept("Child role: read the command from the pipe, open source and destination, copy the data,");
    trace_concept("            update the shared statistics, send the result back through the second pipe.");
    trace_concept("Process state flow:  Child: NEW -> READY -> RUNNING -> TERMINATED");
    trace_concept("                     Parent: RUNNING -> WAITING (blocked in read/waitpid) -> RUNNING");

    char msg[2 * PATH_LEN + 16];
    int mlen = snprintf(msg, sizeof msg, "COPY %s %s", src, dst);

    trace_heading("CO-3: IPC Pipe View");
    trace_real   ("Command pipe : parent writes to FD %d  --->  child reads from FD %d", cmd_w, cmd_r);
    trace_real   ("Result pipe  : child writes to FD %d   --->  parent reads from FD %d", res_w, res_r);
    trace_real   ("Message sent to the child: %s", msg);
    trace_concept("A pipe is a one-way kernel buffer, so two pipes give two-way communication.");

    if (write_all(cmd_w, msg, (size_t)mlen) == -1) {
        int err = errno;
        report_error("write(command pipe)", err);
    }
    close(cmd_w);                                /* closing = "end of message" for the child */

    /* ---- the parent waits here; the child prints its own view and copies ---- */
    char result[300];
    ssize_t rn = read_retry(res_r, result, sizeof result - 1);
    if (rn < 0) { report_error("read(result pipe)", errno); rn = 0; }
    result[rn] = '\0';
    close(res_r);

    int status = 0;
    pid_t w;
    do { w = waitpid(pid, &status, 0); } while (w == -1 && errno == EINTR);
    if (w == -1) report_error("waitpid()", errno);

    g_pipe_cmd[0] = g_pipe_cmd[1] = g_pipe_res[0] = g_pipe_res[1] = -1;
    int copied_ok = (w == pid && WIFEXITED(status) && WEXITSTATUS(status) == 0);

    printf("\nCopy %s: %s\n", copied_ok ? "finished" : "FAILED", result[0] ? result : "(no message from the child)");
    log_event("copy \"%s\" -> \"%s\" by child PID %d: %s", src, dst, (int)pid, result[0] ? result : "no result");

    if (g_learning) {
        trace_heading("CO-3: IPC Pipe View (result)");
        trace_real("Message received from the child: %s", result[0] ? result : "(none)");

        trace_heading("CO-2: Process Lifecycle (result)");
        if (w == pid && WIFEXITED(status)) trace_real("waitpid() returned child PID %d, exit status %d", (int)w, WEXITSTATUS(status));
        else if (w == pid && WIFSIGNALED(status)) trace_real("waitpid(): child was killed by signal %d", WTERMSIG(status));
        trace_real("SIGCHLD handler ran %ld time(s) during this copy (sigaction handler sets a counter)",
                   (long)(g_sigchld_count - sigchld_before));
        trace_concept("The child became a ZOMBIE when it exited; waitpid() collected its status and removed it.");

        trace_heading("CO-4: Memory Management View");
        trace_real("Parent's ordinary variable g_private_counter = %d   (the child set ITS copy to 42)", g_private_counter);
        trace_real("Shared statistics region at %p: bytes written so far %ld (this copy added %ld)",
                   (void *)g_stats, g_stats->bytes_written, g_stats->bytes_written - before_bytes);
        trace_real("Worker status in shared memory: %s",
                   g_stats->worker_status == WORKER_COMPLETED ? "COMPLETED" : g_stats->worker_status == WORKER_FAILED ? "FAILED" : "other");
        trace_concept("After fork() ordinary memory is separate (copy-on-write), but mmap(MAP_SHARED|MAP_ANONYMOUS) is visible to both.");

        struct stat st_new;
        if (copied_ok && stat(dst, &st_new) == 0) {
            trace_heading("CO-5: File System View");
            trace_real("Destination \"%s\": inode %llu, %lld bytes (different inode = a new file)", dst,
                       (unsigned long long)st_new.st_ino, (long long)st_new.st_size);
        }
        trace_thread_view();
    }
    trace_end();
}

/* ======================================================================
 * Option 11: shared I/O statistics                                  CO-4
 * ====================================================================== */
static const char *worker_name(int status)
{
    switch (status) {
    case WORKER_IDLE:      return "IDLE (no copy started yet)";
    case WORKER_RUNNING:   return "RUNNING";
    case WORKER_COMPLETED: return "COMPLETED";
    case WORKER_FAILED:    return "FAILED";
    default:               return "unknown";
    }
}

static void action_stats(void)
{
    trace_begin("shared I/O statistics");
    trace_heading("CO-4: Memory Management View");
    trace_concept("1. The counters below live in memory created with mmap(MAP_SHARED | MAP_ANONYMOUS).");
    trace_concept("2. The parent process AND the child worker process both update this same memory.");
    trace_real   ("3. The shared region is at virtual address %p and is %zu bytes long.", (void *)g_stats, sizeof(IOStats));

    printf("\nShared I/O statistics:\n");
    printf("  +-----------------------+-------------+\n");
    printf("  | Files opened          | %11ld |\n", g_stats->files_opened);
    printf("  | read() calls          | %11ld |\n", g_stats->reads);
    printf("  | write() calls         | %11ld |\n", g_stats->writes);
    printf("  | Bytes read            | %11ld |\n", g_stats->bytes_read);
    printf("  | Bytes written         | %11ld |\n", g_stats->bytes_written);
    printf("  | Errors                | %11ld |\n", g_stats->errors);
    printf("  | Copies completed      | %11ld |\n", g_stats->copies_done);
    printf("  +-----------------------+-------------+\n");
    printf("  Worker status: %s\n", worker_name(g_stats->worker_status));
    log_event("showed the shared I/O statistics");

    if (g_learning) {
        trace_real   ("These numbers are real counters updated by the program's own system-call wrappers.");
        trace_concept("Ordinary variables are copied by fork() (separate after that);");
        trace_concept("a MAP_SHARED mapping is NOT copied: parent and child see the same physical pages.");
        trace_thread_view();
    }
    trace_end();
}

/* ======================================================================
 * Option 12: show the audit log                                     CO-6
 * ====================================================================== */
static void action_audit_log(void)
{
    char buf[1024];

    wait_logger_idle();                          /* make sure everything queued is written */

    trace_begin("audit.log");
    trace_heading("CO-1: User Space to Kernel Space");
    trace_concept("1. audit.log is a normal file written by the LOGGER THREAD with write().");
    trace_concept("2. To show it, this program opens it again for reading:");
    trace_line("\nSystem calls requested:");
    trace_line("  open(\"audit.log\", O_RDONLY), read(...), write(1, ...), close(...)");

    int fd = open("audit.log", O_RDONLY);
    if (fd == -1) {
        report_error("open(audit.log)", errno);
        trace_end();
        return;
    }
    printf("\n------------------------- audit.log -------------------------\n");
    fflush(stdout);
    long total = 0;
    for (;;) {
        ssize_t n = read(fd, buf, sizeof buf);
        if (n == -1) {
            if (errno == EINTR) continue;
            report_error("read(audit.log)", errno);
            break;
        }
        if (n == 0) break;
        if (write_all(STDOUT_FILENO, buf, (size_t)n) == -1) {
            report_error("write(stdout)", errno);
            break;
        }
        total += n;
    }
    if (total == 0) printf("(the log is empty)\n");
    printf("-------------------------------------------------------------\n");
    if (close(fd) == -1) report_error("close(audit.log)", errno);

    trace_real("Read %ld bytes from audit.log (this log keeps growing across runs).", total);
    if (g_dropped > 0) trace_real("%ld log event(s) were dropped because the queue was full.", g_dropped);
    log_event("showed the audit log");
    trace_thread_view();
    trace_end();
}

/* ======================================================================
 * Menu and main
 * ====================================================================== */
static void print_menu(void)
{
    printf("\n==============================================================\n");
    printf("  Linux FD and File I/O Management System\n");
    printf("  with Internal Execution Visualizer\n");
    printf("==============================================================\n");
    printf("  Mode: %s    Open files: %d\n", g_learning ? "LEARNING (trace ON)" : "BASIC (trace OFF)", tracked_count());
    printf("--------------------------------------------------------------\n");
    printf("   1. Select Basic Mode or Learning Mode\n");
    printf("   2. Open/Create file\n");
    printf("   3. Write text to file\n");
    printf("   4. Read file content\n");
    printf("   5. Move file offset with lseek()\n");
    printf("   6. Display current file offset\n");
    printf("   7. Show active file descriptors\n");
    printf("   8. Duplicate descriptor with dup()\n");
    printf("   9. Redirect stdout using dup2()\n");
    printf("  10. Copy file using child process and pipes\n");
    printf("  11. Display shared I/O statistics\n");
    printf("  12. Show audit log\n");
    printf("  13. Enable/Disable Internal Execution Trace\n");
    printf("  14. Close descriptor\n");
    printf("  15. Exit\n");
}

/* Close everything and release all resources before the program ends. */
static void cleanup_all(void)
{
    for (int i = 0; i < MAX_FILES; i++) {
        if (g_slots[i].fd != -1) {
            if (close(g_slots[i].fd) == -1) report_error("close()", errno);
            else printf("Closed FD %d (%s) before exiting.\n", g_slots[i].fd, g_slots[i].name);
            slot_remove(&g_slots[i]);
        }
    }
    log_event("session ended");
    logger_stop();                               /* waits for the log, joins the thread, destroys mutex/semaphore */
    if (g_stats != NULL) {
        if (munmap(g_stats, sizeof(IOStats)) == -1) perror("munmap");
        g_stats = NULL;
    }
}

int main(void)
{
    long choice;

    for (int i = 0; i < MAX_FILES; i++) g_slots[i].fd = -1;

    install_signal_handlers();

    /* CO-4: shared memory for the statistics (zero-filled by the kernel) */
    g_stats = mmap(NULL, sizeof(IOStats), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (g_stats == MAP_FAILED) {
        perror("mmap");
        return 1;
    }

    logger_start();
    log_event("session started, PID %d", (int)getpid());

    printf("Welcome! This program shows what Linux does when you use files.\n");
    printf("Tip: press Ctrl+C at any prompt to exit safely.\n");
    select_mode();

    while (!g_sigint) {
        print_menu();
        if (read_number("Your choice: ", &choice) != 0)
            break;                               /* end of input or Ctrl+C */

        switch (choice) {
        case 1:  select_mode();        break;
        case 2:  action_open();        break;
        case 3:  action_write();       break;
        case 4:  action_read();        break;
        case 5:  action_lseek();       break;
        case 6:  action_show_offset(); break;
        case 7:  action_fd_table();    break;
        case 8:  action_dup();         break;
        case 9:  action_dup2();        break;
        case 10: action_copy();        break;
        case 11: action_stats();       break;
        case 12: action_audit_log();   break;
        case 13: toggle_trace();       break;
        case 14: action_close();       break;
        case 15: goto done;
        default: printf("Invalid choice. Type a number from the menu.\n");
        }
    }

done:
    if (g_sigint)
        printf("\nSIGINT (Ctrl+C) was caught by our sigaction() handler: cleaning up before exit.\n");
    cleanup_all();
    printf("Goodbye!\n");
    return 0;
}
